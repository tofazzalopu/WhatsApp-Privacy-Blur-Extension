# WhatsApp Privacy Shield for Microsoft Edge — v1.0.0

Privacy blur controls for WhatsApp Web. Eight independent toggles, one global
blur strength, and hover-to-reveal on everything that gets blurred.

**Built for Microsoft Edge.** This is a Manifest V3 extension targeting Edge
109 or newer (`minimum_chrome_version: 109`). Edge supports the
Chromium-compatible extension APIs, so it will also load in Chrome, but the
packaging, install steps, and testing here are Edge-first.

## Files

- `manifest.json` — Edge/MV3 extension declaration
- `background.js` — settings defaults, toolbar ON/OFF badge, tab synchronization
- `popup.html` / `popup.css` / `popup.js` — control panel
- `content.js` — WhatsApp Web privacy engine
- `privacy.css` — all protection/reveal styling
- `icons/` — toolbar icons

## Eight controls

1. Contact Names
2. Profile Pictures
3. Group Names & Pictures (one combined toggle)
4. Message Previews
5. Chat messages
6. Media & Attachments
7. Input Fields
8. Unread Message list (first two words of the message, sender hidden)

The master switch controls all eight. A **single global blur-strength control**
in the top toggle bar sets the blur radius (2–20px) for every enabled feature
at once — there is no per-feature slider. Protected content is always revealed
on hover/focus.

## Installing in Microsoft Edge

1. Extract this folder.
2. Open `edge://extensions/`.
3. Enable **Developer mode** (left sidebar).
4. Select **Load unpacked**.
5. Choose the extracted folder.
6. Open or reload `https://web.whatsapp.com/`.

After changing extension files, press the **reload** icon on the extension's
card in `edge://extensions/`, then reload the WhatsApp Web tab.

## Important testing note

WhatsApp Web changes frequently. The content engine deliberately uses several
semantic/structural fallbacks instead of relying on one internal class name,
but selectors can still need maintenance after a WhatsApp Web redesign.

---

## v1.0.0 fixes

### Media & Attachments no longer double-blurs with Message Previews

Message Previews used to blur whole chat-row containers, and if a row's snippet
sat inside a container that also held a thumbnail, that image ended up blurred
twice — once by Media & Attachments and once by the preview blur stacked on its
ancestor — so media looked blurrier whenever Previews was on. Previews now marks
**only the last-message snippet text**, never media or any element that contains
media, so the two features can never touch the same pixels. Chat messages and
the compose box are excluded the same way.

### Group Names + Group Pictures merged into one working toggle

The two separate group controls are now a single **Group Names & Pictures**
switch. Group vs. contact is decided per row/header from several signals — a
default group avatar icon (`data-icon` containing "group"), group/participants/
members keywords, or the "Sender: message" prefix that only group snippets show
— and a row's name and avatar are always classified together. Detection is
case-insensitive and tolerant of emoji and special characters in the name.

### Open conversation now blurs too

Header selectors are anchored on the stable `#main` / `#pane-side` ids instead
of relying only on `data-testid` attributes WhatsApp has largely removed, so the
open chat's **group photo, header name, and message text ("characters")** now
blur along with the chat list.

### Unread list: first two words, sender hidden

Unread rows now **hide the sender/contact name** (blurred, tooltip cleared) and
truncate the snippet to the **first two words of the message** — any leading
"Sender: " group prefix is stripped first so the sender never leaks. The two
words stay readable; hover/focus reveals the full original message.

### Courtesy note

Added "❤️ from Tofazzal Opu" at the bottom of the popup.

---


### Media & Attachments toggle did nothing

`privacy.css` matched `[data-wps-media="1"] img` — a **descendant** selector —
while `content.js` marks the `<img>` element itself. That rule therefore never
matched, so media blur was never actually applied. The blur visible on images
was coming from the Profile Pictures pass, which is why switching Media &
Attachments off appeared to have no effect.

Two changes:

- Selectors now target the marked element itself. A CSS `filter` already blurs
  the element's entire subtree, so descendant selectors were redundant as well
  as broken.
- Pictures and media now have **mutually exclusive** candidate rules. A square
  image 24–220px inside a list row, header, or side panel is treated as an
  avatar and owned by the Profile/Group Pictures toggles; anything else larger
  than 80×50 is owned by Media & Attachments. Each toggle now controls a
  distinct set of elements, so each one visibly does something.

### Constant screen blinking

`process()` ran `clearAllProtection()` on **every** DOM mutation, which removed
`html[data-wps-master]` and every blur attribute, then re-added them a moment
later. WhatsApp Web mutates continuously, so the whole page was unblurring and
reblurring several times a second. The `transition: filter .12s` rules made
each cycle a visible pulse.

- Marking is now **incremental**. Every pass stamps the elements it claims with
  a pass token, then sweeps only elements the current pass did *not* claim.
  Elements that stay protected are never touched between passes.
- `html[data-wps-master="on"]` is set once and only removed when the master
  switch actually turns off.
- CSS custom properties are only written when the value actually changes.
- `transition` on `filter` was removed entirely — besides flickering, animating
  a blur briefly exposes the content it is meant to hide.
- Passes are skipped while the tab is hidden, and re-run on `visibilitychange`.

### Unread Message list masking

The old code collected every `span`/`div` in an unread row and picked the one
with the longest text — which is normally the **row container**, so the contact
name and timestamp were truncated to three characters along with the preview.

- Targeting now resolves the preview element specifically, via WhatsApp's
  `cell-frame-secondary` / `last-msg-status` test IDs, with a fallback that
  requires a **leaf-ish** element (no child `span`/`div`), no `title`
  attribute, and a position on the row's lower line. It can no longer select a
  container.
- Masking stays non-destructive: original child nodes are kept and re-inserted
  verbatim, so nested spans, emoji, and formatting survive.
- If WhatsApp re-renders a row and replaces our text node, the originals are
  re-captured instead of restoring stale text.
- A `revealed` flag means hover/focus reveal is no longer instantly re-masked
  by the next pass.

### New toolbar icon

Regenerated at 16/32/48/128: an indigo→violet rounded tile with a white
shield whose right half is genuinely Gaussian-blurred, matching the popup's
accent colors. Small sizes use a gentler blur so the silhouette stays legible.

---


### Single global blur strength

- Removed the per-feature blur-strength slider from every row/panel.
- Added one global blur-strength slider in the top toggle bar, applying the
  same 2–20px blur to all enabled features.
- Storage uses a single `blurStrength` key instead of nine `*Strength` keys.

### "State doesn't come back to original" fixes

- **Non-destructive unread masking.** The unread feature no longer overwrites
  `textContent` (which permanently destroyed WhatsApp's nested spans, emoji,
  and formatting).
- **Reliable observer suppression.** All DOM writes the extension makes are
  performed with the MutationObserver disconnected, then reconnected. A boolean
  flag was ineffective because observer callbacks fire asynchronously.
- **Exact title restoration.** Original `title` attributes are saved once and
  restored precisely when protection is cleared.


- Feature switches have a single source of truth in `storage.local`.
- Switch state renders immediately before storage completes.
- Master and per-feature switches are independent booleans; feature switches
  stay clickable when Master is OFF.
- Master OFF removes all extension-owned protection from the page.
