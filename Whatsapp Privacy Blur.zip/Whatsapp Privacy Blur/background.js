const api = globalThis.browser ?? globalThis.chrome;

const DEFAULTS = {
  master: true,
  contactNames: true,
  profilePictures: true,
  // Group names AND group pictures are one control now.
  groups: true,
  messagePreviews: true,
  chatMessages: true,
  mediaAttachments: true,
  inputFields: true,
  unreadMessageList: true,
  // Single global blur strength shared by every feature.
  blurStrength: 10
};

async function getSettings() {
  const result = await api.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...result };
}

async function updateBadge() {
  const settings = await getSettings();
  const on = !!settings.master;
  try {
    await api.action.setBadgeText({ text: on ? "ON" : "OFF" });
    await api.action.setBadgeBackgroundColor({ color: on ? "#14b86e" : "#697386" });
    await api.action.setTitle({
      title: on ? "WhatsApp Privacy Shield — ON" : "WhatsApp Privacy Shield — OFF"
    });
  } catch (_) {}
}

async function pushSettingsToTabs() {
  const settings = await getSettings();
  try {
    const tabs = await api.tabs.query({ url: ["https://web.whatsapp.com/*"] });
    await Promise.allSettled(
      tabs.map(tab => api.tabs.sendMessage(tab.id, {
        type: "WPS_SETTINGS",
        settings
      }))
    );
  } catch (_) {}
}

api.runtime.onInstalled.addListener(async () => {
  const existing = await api.storage.local.get(null);
  if (Object.keys(existing).length === 0) {
    await api.storage.local.set(DEFAULTS);
  } else {
    await api.storage.local.set({ ...DEFAULTS, ...existing });
  }
  await updateBadge();
});

api.runtime.onStartup?.addListener(updateBadge);

api.storage.onChanged.addListener(async () => {
  await updateBadge();
  await pushSettingsToTabs();
});

api.runtime.onMessage.addListener((message, sender) => {
  if (!message || !message.type) return;
  if (message.type === "WPS_REFRESH_BADGE") {
    return updateBadge();
  }
});

updateBadge();
