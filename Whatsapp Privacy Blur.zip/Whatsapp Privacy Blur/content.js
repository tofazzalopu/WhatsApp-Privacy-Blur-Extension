(() => {
  "use strict";

  const api = globalThis.browser ?? globalThis.chrome;

  const ATTR = "data-wps-protect";
  const MEDIA_ATTR = "data-wps-media";
  const INPUT_ATTR = "data-wps-input";
  const FEATURE_ATTR = "data-wps-feature";
  const TITLE_ATTR = "data-wps-title-original";
  const UNREAD_ATTR = "data-wps-unread";
  const PASS_ATTR = "data-wps-pass";

  const DEFAULTS = {
    master: true,
    contactNames: true,
    profilePictures: true,
    // Group names AND group pictures are now a single control.
    groups: true,
    messagePreviews: true,
    chatMessages: true,
    mediaAttachments: true,
    inputFields: true,
    unreadMessageList: true,
    // Single global blur strength shared by every feature.
    blurStrength: 10
  };

  const MIN_STRENGTH = 2;
  const MAX_STRENGTH = 20;
  const OBSERVER_OPTS = { subtree: true, childList: true };

  // Containers where a square image is an avatar rather than shared media.
  const AVATAR_CONTEXT =
    '#pane-side, #main header, [role="row"], [role="listitem"], ' +
    '[data-testid="cell-frame-container"], header, [data-testid="chat-list"], ' +
    '[role="grid"], [role="dialog"], [data-testid="drawer-right"], ' +
    '[data-testid="drawer-left"]';

  let settings = { ...DEFAULTS };
  let observer = null;
  let timer = 0;

  // Monotonic pass counter. Elements are stamped with the pass that claimed
  // them; anything not stamped by the current pass is swept (unmarked). This
  // is what keeps already-blurred elements completely untouched between
  // passes — the previous clear-everything-then-reapply approach made the
  // whole page flash on every WhatsApp DOM mutation.
  let pass = 0;
  let masterApplied = false;
  let lastRun = 0;

  // Whether the currently open conversation (#main) is a group. Computed once
  // per pass from the chat JID and reused, so we don't re-scan on every element.
  //   true  = group   |   false = individual   |   null = unknown / no chat open
  let openChatGroup = null;

  const MAX_WAIT = 1200;   // ms — debounce ceiling, see scheduleProcess()
  const SAFETY_NET = 2000; // ms — periodic pass, see boot()

  // target element -> { nodes, original, masked, revealed }
  const maskedUnread = new Map();

  const token = () => String(pass);
  const normalize = value => (value || "").replace(/\s+/g, " ").trim();

  function blurStrength() {
    const n = Number(settings.blurStrength);
    if (!Number.isFinite(n)) return DEFAULTS.blurStrength;
    return Math.max(MIN_STRENGTH, Math.min(MAX_STRENGTH, Math.round(n)));
  }

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function text(el) {
    return normalize(el?.innerText || el?.textContent || "");
  }

  function aria(el) {
    return normalize(el?.getAttribute?.("aria-label") || "");
  }

  function labelText(el) {
    return `${text(el)} ${aria(el)} ${normalize(el?.getAttribute?.("title") || "")}`.toLowerCase();
  }

  function nodesText(nodes) {
    return normalize(nodes.map(n => n.textContent || "").join(""));
  }

  // Unread snippet masking: show the first two WORDS of the message.
  // A leading "Sender: " prefix (used in group chats) is stripped first so we
  // never leak the sender's name, and matching is case/character agnostic.
  function firstTwoWords(value) {
    const raw = normalize(value);
    if (!raw) return raw;
    const stripped = raw.replace(/^[^:\n]{1,40}:\s+/, "");
    const base = stripped || raw;
    const words = base.split(/\s+/).filter(Boolean);
    if (words.length <= 2) return base;
    return `${words.slice(0, 2).join(" ")}…`;
  }

  function containsMedia(el) {
    return !!(el && el.querySelector && el.querySelector("img, video, canvas"));
  }

  // Only write a custom property when it actually changes, so we never
  // trigger needless style recalculation (another source of visible churn).
  function setVar(el, name, value) {
    if (el.style.getPropertyValue(name) !== value) el.style.setProperty(name, value);
  }

  // Run OUR DOM writes with the observer detached, so the extension never
  // reacts to changes it made itself. A boolean flag is not enough here:
  // MutationObserver callbacks are delivered asynchronously, after the flag
  // has already been reset.
  //
  // Depth-counted because these calls can nest: the unread hover handlers use
  // mutateSilently too, and a naive implementation would let the inner call's
  // `finally` reconnect the observer while an outer pass is still writing —
  // which would make the extension observe itself again.
  let silenceDepth = 0;

  function mutateSilently(fn) {
    if (silenceDepth === 0 && observer) observer.disconnect();
    silenceDepth++;
    try {
      return fn();
    } finally {
      silenceDepth--;
      if (silenceDepth === 0 && observer) {
        observer.observe(document.documentElement || document.body, OBSERVER_OPTS);
      }
    }
  }

  function varNameFor(attr) {
    if (attr === MEDIA_ATTR) return "--wps-media-blur";
    if (attr === INPUT_ATTR) return "--wps-input-blur";
    return "--wps-blur";
  }

  /* ---------------------------------------------------------------------- */
  /* structural helpers                                                     */
  /* ---------------------------------------------------------------------- */

  // Chat-list rows on the left pane. Anchored on #pane-side (a very stable
  // WhatsApp Web id) so this keeps working even as data-testid attributes come
  // and go across redesigns.
  function chatRows() {
    const set = new Set();
    document
      .querySelectorAll(
        '#pane-side [role="listitem"], #pane-side [role="row"], ' +
        '[data-testid="cell-frame-container"], div[role="grid"] [role="row"]'
      )
      .forEach(r => set.add(r));
    return [...set];
  }

  // The contact/group title of a chat row is the element carrying a title attr.
  function findRowName(row) {
    return (
      row.querySelector('span[title][dir="auto"]') ||
      row.querySelector("span[title]")
    );
  }

  // The last-message preview element of a row. Must never be a container: the
  // original bug picked the longest span/div in the row (usually the whole
  // row), truncating the name + timestamp. It must also never be or contain
  // media, so the Message Previews feature can never stack blur onto an image.
  function findPreviewText(row) {
    if (!row || !row.querySelector) return null;

    const preferred = row.querySelector(
      '[data-testid="cell-frame-secondary"] span[dir="ltr"], ' +
      '[data-testid="cell-frame-secondary"] span[dir="auto"], ' +
      '[data-testid="last-msg-status"] span[dir="ltr"], ' +
      '[data-testid="last-msg-status"] span[dir="auto"]'
    );
    if (preferred && text(preferred) && !containsMedia(preferred)) return preferred;

    const rowRect = row.getBoundingClientRect();
    const midY = rowRect.top + rowRect.height / 2;

    const candidates = Array.from(row.querySelectorAll("span, div")).filter(el => {
      if (el.hasAttribute("title")) return false;                          // the name
      if (el.querySelector("span, div, img, video, canvas")) return false; // leaf, no media
      const value = text(el);
      if (value.length < 2 || value.length > 200) return false;
      if (/^\d{1,3}$/.test(value)) return false;                           // unread count badge
      const r = el.getBoundingClientRect();
      if (r.width < 12 || r.height <= 0) return false;
      return r.top >= midY - 4;                                           // lower line
    });

    candidates.sort((a, b) => text(b).length - text(a).length);
    return candidates[0] || null;
  }

  // Authoritative, language-independent group signal: the chat JID. WhatsApp
  // tags message rows (and some containers) with a data-id that embeds the
  // chat id — group ids end in "@g.us", individuals in "@c.us" /
  // "@s.whatsapp.net". This is completely independent of the group's NAME, so
  // case, emoji and special characters never matter.
  //   returns true = group, false = individual, null = no id found in scope
  function jidIsGroup(scope) {
    if (!scope || !scope.querySelector) return null;
    const withId = scope.querySelector(
      '[data-id*="@g.us"], [data-id*="@c.us"], [data-id*="@s.whatsapp.net"]'
    );
    if (!withId) return null;
    return (withId.getAttribute("data-id") || "").includes("@g.us");
  }

  // Group vs. individual, computed at container level so a row's name and
  // avatar are always classified the same way. The JID is authoritative; the
  // rest are best-effort fallbacks for the chat list, which exposes no JID.
  //   * default group avatar icon / group aria-labels
  //   * group / participants / members / community keywords (case-insensitive,
  //     tolerant of emoji and special characters in the actual name)
  //   * a real "Sender: message" prefix in the preview (only groups show it;
  //     "You:" is used in 1:1 chats too, so it doesn't count)
  function isGroupContext(el) {
    // 1) Open conversation: use the JID of the whole #main pane (cached).
    const main = el.closest && el.closest("#main");
    if (main && openChatGroup !== null) return openChatGroup;

    const container =
      el.closest(
        '#main header, header, [role="row"], [role="listitem"], ' +
        '[data-testid="cell-frame-container"]'
      ) || el.parentElement;
    if (!container) return false;

    const jid = jidIsGroup(container);
    if (jid !== null) return jid;

    if (container.querySelector(
        '[data-icon*="group" i], [aria-label*="group" i], ' +
        '[aria-label*="participant" i], [aria-label*="member" i]'
      )) return true;

    const label = labelText(container);
    if (/\bgroups?\b|participants?|\bmembers\b|community|\bgrupo\b/.test(label)) return true;

    const preview = findPreviewText(container);
    if (preview) {
      const m = text(preview).match(/^([^:\n]{1,30}):\s/);
      if (m && !/^you\b/i.test(m[1].trim())) return true;
    }

    return false;
  }

  /* ---------------------------------------------------------------------- */
  /* marking + sweeping                                                     */
  /* ---------------------------------------------------------------------- */

  function mark(el, feature, attr = ATTR) {
    if (!(el instanceof Element)) return false;

    // One feature owns an element per pass — first claim wins. This keeps the
    // per-feature toggles meaningful instead of several features fighting over
    // the same node.
    if (el.getAttribute(PASS_ATTR) === token()) return false;
    el.setAttribute(PASS_ATTR, token());

    // Drop any protection kind this element no longer belongs to.
    for (const other of [ATTR, MEDIA_ATTR, INPUT_ATTR]) {
      if (other !== attr && el.hasAttribute(other)) {
        el.removeAttribute(other);
        el.style.removeProperty(varNameFor(other));
      }
    }

    if (el.getAttribute(attr) !== "1") el.setAttribute(attr, "1");
    if (el.getAttribute(FEATURE_ATTR) !== feature) el.setAttribute(FEATURE_ATTR, feature);
    setVar(el, varNameFor(attr), `${blurStrength()}px`);
    return true;
  }

  function restoreTitle(el) {
    if (!el.hasAttribute(TITLE_ATTR)) return;
    const original = el.getAttribute(TITLE_ATTR);
    if (original != null) el.setAttribute("title", original);
    el.removeAttribute(TITLE_ATTR);
  }

  // Put the original child nodes back exactly as they were.
  function restoreUnread(el) {
    const entry = maskedUnread.get(el);
    maskedUnread.delete(el);
    if (!entry) return;

    if (el.isConnected) {
      // Only rewrite children if the content is still OURS. If WhatsApp
      // re-rendered this row and replaced our masked node, the saved originals
      // are stale and writing them back would resurrect outdated text.
      const oursMasked = entry.masked && entry.masked.parentNode === el;
      const oursRevealed = entry.revealed && entry.nodes.some(n => n.parentNode === el);

      if (oursMasked || oursRevealed) el.replaceChildren(...entry.nodes);

      el.removeAttribute(UNREAD_ATTR);
      el.style.removeProperty("--wps-blur");
    }
  }

  function unmark(el) {
    restoreUnread(el);
    restoreTitle(el);

    for (const attr of [ATTR, MEDIA_ATTR, INPUT_ATTR]) {
      if (el.hasAttribute(attr)) {
        el.removeAttribute(attr);
        el.style.removeProperty(varNameFor(attr));
      }
    }
    el.removeAttribute(FEATURE_ATTR);
    el.removeAttribute(PASS_ATTR);
    el.removeAttribute(UNREAD_ATTR);
  }

  // Release only what the current pass did NOT claim.
  function sweep() {
    const current = token();
    document.querySelectorAll(`[${PASS_ATTR}]`).forEach(el => {
      if (el.getAttribute(PASS_ATTR) !== current) unmark(el);
    });

    // Elements WhatsApp has since removed from the document.
    for (const el of Array.from(maskedUnread.keys())) {
      if (!el.isConnected) maskedUnread.delete(el);
    }
  }

  function fullClear() {
    for (const el of Array.from(maskedUnread.keys())) restoreUnread(el);
    maskedUnread.clear();

    document
      .querySelectorAll(`[${PASS_ATTR}], [${ATTR}], [${MEDIA_ATTR}], [${INPUT_ATTR}], [${UNREAD_ATTR}]`)
      .forEach(unmark);

    document.querySelectorAll(`[${TITLE_ATTR}]`).forEach(restoreTitle);

    document.documentElement.removeAttribute("data-wps-master");
    masterApplied = false;
  }

  /* ---------------------------------------------------------------------- */
  /* feature passes                                                         */
  /* ---------------------------------------------------------------------- */

  function applyNames() {
    if (!settings.contactNames && !settings.groups) return;

    const candidates = document.querySelectorAll(
      '#pane-side span[title], ' +
      '#main header span[title], ' +
      '#main header span[dir="auto"], ' +
      '[data-testid="conversation-header"] span[dir="auto"], ' +
      '[role="main"] header span[title], ' +
      'div[role="grid"] span[title], ' +
      'span[title]'
    );

    for (const el of candidates) {
      if (!isVisible(el)) continue;

      const value = normalize(el.getAttribute("title") || text(el));
      if (!value || value.length > 90) continue;

      const container = el.closest("header, [role='row'], [role='listitem'], [data-testid='cell-frame-container']");
      const semantic = labelText(container || el);
      if (/unread|notification|status|search|settings|close/.test(semantic)) continue;

      const grp = isGroupContext(el);
      const on = grp ? settings.groups : settings.contactNames;
      if (!on) continue;

      if (!mark(el, grp ? "groups" : "contactNames")) continue;

      const title = el.getAttribute("title");
      if (title && !el.hasAttribute(TITLE_ATTR)) {
        el.setAttribute(TITLE_ATTR, title);
        el.setAttribute("title", "");
      }
    }
  }

  // The open conversation's TOP BAR (#main header): profile photo, the chat
  // name, and the subtitle line (group members list, or "online"/"last seen"
  // for a 1:1). WhatsApp has dropped most of the data-testid hooks here, so
  // this pass is deliberately structural and self-contained instead of relying
  // on the generic name/picture passes — that's why the header used to stay
  // sharp. Group vs. individual comes from the cached JID and is therefore
  // independent of the group's name.
  function applyConversationHeader() {
    const header = document.querySelector("#main header, [role='main'] header");
    if (!header || !isVisible(header)) return;

    const grp = openChatGroup === null ? isGroupContext(header) : openChatGroup;
    const nameOn = grp ? settings.groups : settings.contactNames;
    const picOn = grp ? settings.groups : settings.profilePictures;
    const feature = grp ? "groups" : null;

    // Profile photo — any real image in the header.
    if (picOn) {
      for (const img of header.querySelectorAll("img")) {
        if (!isVisible(img)) continue;
        const r = img.getBoundingClientRect();
        if (r.width < 20 || r.height < 20) continue;
        mark(img, feature || "profilePictures");
      }
    }

    // Name + subtitle — the innermost text-bearing spans/headings, skipping the
    // action icons (search / menu / call), which carry no visible text. We look
    // for the innermost [dir]/[title] span so emoji and special characters in
    // the name (rendered as child <img> emoji) are still covered.
    if (nameOn) {
      for (const el of header.querySelectorAll('span[dir], span[title], h1, h2')) {
        if (!isVisible(el)) continue;
        if (el.querySelector('span[dir], span[title]')) continue; // not a wrapper
        const value = text(el);
        if (!value || value.length > 200) continue;

        if (!mark(el, feature || "contactNames")) continue;

        const title = el.getAttribute("title");
        if (title && !el.hasAttribute(TITLE_ATTR)) {
          el.setAttribute(TITLE_ATTR, title);
          el.setAttribute("title", "");
        }
      }
    }
  }
  function isAvatarLike(el) {
    const r = el.getBoundingClientRect();
    if (Math.abs(r.width - r.height) >= 8) return false;
    if (r.width < 24 || r.width > 220) return false;
    return !!el.closest(AVATAR_CONTEXT) || r.width <= 72;
  }

  function applyPictures() {
    if (!settings.profilePictures && !settings.groups) return;

    for (const img of document.querySelectorAll("img")) {
      if (!isVisible(img) || !isAvatarLike(img)) continue;

      const grp = isGroupContext(img);
      const on = grp ? settings.groups : settings.profilePictures;
      if (!on) continue;

      mark(img, grp ? "groups" : "profilePictures");
    }
  }

  // Message Previews blurs ONLY the last-message snippet text of each chat-list
  // row. It never marks media or an element that contains media, so it can no
  // longer stack a second blur on top of the Media & Attachments feature.
  function applyPreviews() {
    if (!settings.messagePreviews) return;

    for (const row of chatRows()) {
      if (!isVisible(row)) continue;

      const el = findPreviewText(row);
      if (!el || !isVisible(el) || containsMedia(el)) continue;

      // If this row just went unread -> read, restore the full text the unread
      // pass truncated before we blur it as an ordinary preview.
      if (maskedUnread.has(el)) restoreUnread(el);

      const value = text(el);
      if (!value || value.length > 200) continue;

      mark(el, "messagePreviews");
    }
  }

  function applyMedia() {
    if (!settings.mediaAttachments) return;

    const explicit = '[data-testid="media-caption"], [data-testid="image-thumb"], [data-testid="video-thumb"]';
    for (const el of document.querySelectorAll(explicit)) {
      if (isVisible(el)) mark(el, "mediaAttachments", MEDIA_ATTR);
    }

    for (const el of document.querySelectorAll("img, video, canvas")) {
      if (!isVisible(el)) continue;
      if (isAvatarLike(el)) continue;

      const r = el.getBoundingClientRect();
      if (r.width <= 80 || r.height <= 50) continue;

      mark(el, "mediaAttachments", MEDIA_ATTR);
    }
  }

  function applyInputs() {
    if (!settings.inputFields) return;

    for (const el of document.querySelectorAll('input, textarea, [contenteditable="true"]')) {
      if (!isVisible(el)) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 80 || r.height < 20) continue;

      mark(el, "inputFields", INPUT_ATTR);
    }
  }

  // Blur the text of messages in the OPEN conversation ("characters"). Targets
  // the text spans directly (never a bubble that wraps an image, and never the
  // compose box) so it doesn't double-blur media or the input field.
  function applyMessages() {
    if (!settings.chatMessages) return;

    const selectors = [
      '#main span.selectable-text',
      '#main .copyable-text.selectable-text',
      '.message-in span.selectable-text',
      '.message-out span.selectable-text',
      '#main [data-pre-plain-text] .copyable-text',
      '[data-pre-plain-text] .copyable-text'
    ];

    const seen = new Set();
    for (const selector of selectors) {
      for (const el of document.querySelectorAll(selector)) {
        if (seen.has(el)) continue;
        seen.add(el);
        if (!isVisible(el)) continue;
        if (containsMedia(el)) continue;                       // leave media to its own feature
        if (el.closest('[contenteditable="true"]')) continue;  // leave the compose box to Input Fields

        const r = el.getBoundingClientRect();
        if (r.width > 40 && r.height > 8) mark(el, "chatMessages");
      }
    }
  }

  /* ---------------------------------------------------------------------- */
  /* unread list: hide the sender, show first two words of the message      */
  /* ---------------------------------------------------------------------- */

  function isUnreadRow(row) {
    const semantic = labelText(row);
    return (
      /unread|new message|new messages/.test(semantic) ||
      !!row.querySelector('[data-testid*="unread"], [aria-label*="unread" i]')
    );
  }

  function bindUnreadReveal(target) {
    if (target.dataset.wpsRevealBound) return;

    const reveal = () => {
      const entry = maskedUnread.get(target);
      if (!entry || entry.revealed) return;
      entry.revealed = true;
      mutateSilently(() => target.replaceChildren(...entry.nodes));
    };
    const hide = () => {
      const entry = maskedUnread.get(target);
      if (!entry || !entry.revealed) return;
      entry.revealed = false;
      mutateSilently(() => target.replaceChildren(entry.masked));
    };

    target.addEventListener("mouseenter", reveal);
    target.addEventListener("mouseleave", hide);
    target.addEventListener("focusin", reveal);
    target.addEventListener("focusout", hide);
    target.dataset.wpsRevealBound = "1";
  }

  function applyUnreadList() {
    if (!settings.unreadMessageList) return;

    for (const row of chatRows()) {
      if (!isVisible(row) || !isUnreadRow(row)) continue;

      // 1) Hide the sender / contact name of the unread chat (blurred, and its
      //    tooltip cleared) so you can't tell who the new message is from.
      const name = findRowName(row);
      if (name && isVisible(name) && name.getAttribute(PASS_ATTR) !== token()) {
        if (mark(name, "unreadMessageList")) {
          const title = name.getAttribute("title");
          if (title && !name.hasAttribute(TITLE_ATTR)) {
            name.setAttribute(TITLE_ATTR, title);
            name.setAttribute("title", "");
          }
        }
      }

      // 2) Truncate the preview to the first two words of the message. The
      //    snippet stays readable (not blurred) — that's the whole point — and
      //    hover/focus reveals the full original.
      const target = findPreviewText(row);
      if (!target || target.getAttribute(PASS_ATTR) === token()) continue;

      let entry = maskedUnread.get(target);

      // Hover/focus reveal in progress — leave the DOM completely alone,
      // otherwise the pass would instantly re-mask what the user is reading.
      if (entry && entry.revealed) {
        target.setAttribute(PASS_ATTR, token());
        continue;
      }

      // Already masked and untouched since last pass: no DOM write at all.
      // Node identity alone isn't enough — WhatsApp can write into our text
      // node in place, so verify the contents are still what we put there.
      const intact =
        entry &&
        target.childNodes.length === 1 &&
        target.firstChild === entry.masked &&
        entry.masked.data === firstTwoWords(entry.original);

      if (!intact) {
        // First time, or WhatsApp re-rendered this row and replaced our node.
        const nodes = Array.from(target.childNodes);
        const original = nodesText(nodes);
        if (!original) {
          maskedUnread.delete(target);
          continue;
        }
        const masked = document.createTextNode(firstTwoWords(original));
        entry = { nodes, original, masked, revealed: false };
        maskedUnread.set(target, entry);
        target.replaceChildren(masked);
      }

      target.setAttribute(PASS_ATTR, token());
      bindUnreadReveal(target);
    }
  }

  /* ---------------------------------------------------------------------- */
  /* driver                                                                 */
  /* ---------------------------------------------------------------------- */

  function process() {
    lastRun = Date.now();

    if (document.hidden) return;

    if (!settings.master) {
      if (masterApplied) mutateSilently(fullClear);
      return;
    }

    pass++;

    // Resolve the open conversation's type once per pass from its JID, so every
    // header/message element classifies consistently without re-scanning #main.
    openChatGroup = jidIsGroup(document.querySelector("#main"));

    mutateSilently(() => {
      // Set once, never removed while the master switch stays on. Toggling
      // this attribute every pass is what made the entire page flash.
      if (!masterApplied) {
        document.documentElement.setAttribute("data-wps-master", "on");
        masterApplied = true;
      }

      // Order matters: the most specific claim runs first and wins. Unread
      // claims its rows before Previews so an unread snippet gets the two-word
      // treatment instead of a plain blur. The header pass runs before the
      // generic name/picture passes so it owns the top bar.
      applyUnreadList();
      applyPreviews();
      applyConversationHeader();
      applyNames();
      applyPictures();
      applyMedia();
      applyInputs();
      applyMessages();

      sweep();
    });
  }

  // Debounce, with a hard ceiling. WhatsApp can mutate the DOM continuously
  // (typing indicators, presence, timers), and a pure debounce would keep
  // resetting and never actually run — leaving newly arrived content
  // unblurred. MAX_WAIT forces a pass through.
  function scheduleProcess(delay = 90) {
    clearTimeout(timer);

    if (Date.now() - lastRun >= MAX_WAIT) {
      process();
      return;
    }
    timer = setTimeout(process, delay);
  }

  async function loadSettings() {
    const stored = await api.storage.local.get(DEFAULTS);
    settings = { ...DEFAULTS, ...stored };
    scheduleProcess(20);
  }

  function boot() {
    loadSettings();

    observer = new MutationObserver(mutations => {
      for (const m of mutations) {
        if (m.type === "childList" && (m.addedNodes.length || m.removedNodes.length)) {
          scheduleProcess(90);
          return;
        }
      }
    });

    observer.observe(document.documentElement || document.body, OBSERVER_OPTS);

    window.addEventListener("resize", () => scheduleProcess(150), { passive: true });
    window.addEventListener("hashchange", () => scheduleProcess(80), { passive: true });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) scheduleProcess(60);
    });

    // Safety net. Two things the observer alone cannot catch:
    //   * mutations that happen while it is disconnected during our own pass
    //     (disconnect() discards the pending record queue), and
    //   * in-place text edits, since we only watch childList.
    // A pass is idempotent and writes nothing when nothing changed, so running
    // one periodically is cheap and cannot cause flicker.
    setInterval(() => {
      if (!document.hidden) scheduleProcess(90);
    }, SAFETY_NET);
  }

  function onSettingsChanged() {
    // A strength change must refresh the CSS vars on everything already
    // marked, so bump the pass and let mark() rewrite them.
    scheduleProcess(20);
  }

  api.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;

    let changed = false;
    for (const [key, info] of Object.entries(changes)) {
      if (key in settings && info.newValue !== undefined && settings[key] !== info.newValue) {
        settings[key] = info.newValue;
        changed = true;
      }
    }
    if (changed) onSettingsChanged();
  });

  api.runtime.onMessage.addListener(message => {
    if (message?.type === "WPS_SETTINGS" && message.settings) {
      settings = { ...DEFAULTS, ...message.settings };
      onSettingsChanged();
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
