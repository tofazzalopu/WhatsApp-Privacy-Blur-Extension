const api = globalThis.browser ?? globalThis.chrome;

const DEFAULTS = {
  master: true,
  contactNames: true,
  profilePictures: true,
  // Group names AND group pictures are one control now.
  groups: true,
  messagePreviews: true,
  chatMessages: true,
  mediaAttachments: true,
  inputFields: true,
  unreadMessageList: true,
  // Single global blur strength shared by every feature.
  blurStrength: 10
};

const MIN_STRENGTH = 2;
const MAX_STRENGTH = 20;

const keys = Object.keys(DEFAULTS).filter(k => k !== "master" && k !== "blurStrength");

const master = document.getElementById("masterSwitch");
const masterText = document.getElementById("masterText");
const count = document.getElementById("count");
const globalSlider = document.getElementById("globalStrength");
const globalValue = document.getElementById("globalStrengthValue");
const controlBar = globalSlider.closest(".control-bar");

let state = { ...DEFAULTS };

function clampStrength(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return DEFAULTS.blurStrength;
  return Math.max(MIN_STRENGTH, Math.min(MAX_STRENGTH, Math.round(n)));
}

async function readState() {
  const stored = await api.storage.local.get(DEFAULTS);
  state = { ...DEFAULTS, ...stored };
  state.blurStrength = clampStrength(state.blurStrength);
  return state;
}

function render() {
  const masterOn = !!state.master;

  master.classList.toggle("on", masterOn);
  master.classList.toggle("off", !masterOn);
  master.setAttribute("aria-checked", String(masterOn));
  masterText.textContent = masterOn ? "ON" : "OFF";

  // Global blur strength control.
  const strength = clampStrength(state.blurStrength);
  globalSlider.value = String(strength);
  globalValue.textContent = `${strength}px`;
  controlBar.classList.toggle("disabled", !masterOn);

  let enabled = 0;

  document.querySelectorAll(".row[data-key]").forEach(row => {
    const key = row.dataset.key;
    const enabledForFeature = !!state[key];

    if (enabledForFeature) enabled++;

    row.classList.toggle("active", enabledForFeature);
    row.classList.toggle("disabled", !masterOn);

    const button = row.querySelector("[data-toggle]");
    button.setAttribute("aria-pressed", String(enabledForFeature));
    button.textContent = "";
    const dot = document.createElement("span");
    dot.setAttribute("aria-hidden", "true");
    button.appendChild(dot);

    // Individual feature switches remain usable when the master switch is off.
    button.disabled = false;
  });

  count.textContent = `${enabled} / ${keys.length}`;
}

async function setState(patch) {
  state = { ...state, ...patch };
  render();
  await api.storage.local.set(patch);
}

master.addEventListener("click", event => {
  event.preventDefault();
  event.stopPropagation();
  setState({ master: !state.master });
});

document.querySelectorAll("[data-toggle]").forEach(button => {
  button.addEventListener("click", event => {
    event.preventDefault();
    event.stopPropagation();
    const key = button.dataset.toggle;
    setState({ [key]: !state[key] });
  });
});

globalSlider.addEventListener("input", event => {
  const value = clampStrength(event.currentTarget.value);
  // Reflect immediately, then persist.
  state.blurStrength = value;
  globalValue.textContent = `${value}px`;
  setState({ blurStrength: value });
});

api.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName !== "local") return;

  let changed = false;
  for (const [key, info] of Object.entries(changes)) {
    if (key in state && info.newValue !== undefined && state[key] !== info.newValue) {
      state[key] = info.newValue;
      changed = true;
    }
  }
  if (changed) render();
});

(async () => {
  await readState();
  render();
})();
